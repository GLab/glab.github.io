#!/bin/bash
sleep 120
archive_setstatus "I am finished!"

