#!/usr/bin/python
import socket
import sys
import time
import threading

TARGET_IP = sys.argv[1]
MSG = "bender"

class Measurer:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.lock = threading.Lock()

    def measure(self):
        with self.lock:
            stime = time.time()
            self.sock.sendto(MSG, (TARGET_IP, 12345))
            while MSG != self.sock.recv(200):
                pass
            duration = time.time() - stime
        return duration

print Measurer().measure()

