#!/usr/bin/python
import socket

class EchoServer:
    def run(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(None)
        self.sock.bind(("0.0.0.0", 12345))
        try:
            while True:
                msg, src = self.sock.recvfrom(200)
                self.sock.sendto(msg, src)
        except KeyboardInterrupt:
            self.sock.close()

print "start"
EchoServer().run()
print "shut down"

